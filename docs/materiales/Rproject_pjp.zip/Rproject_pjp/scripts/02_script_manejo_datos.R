#- script para seguir las slides sobre manejo de datos

library(tidyverse)
library(gapminder)


#- The pipe ( %>% ) ------------------------------------------------------------

#- slide nº 8 --
#- Las siguientes 2 expresiones hacen exactamente lo mismo:
library(palmerpenguins)
head(penguins, n = 4) #- forma habitual de llamar/usar la función head()
penguins %>% head(. , n = 4) #- usando el operador pipe

#- slide nº 9 --
#- Estas 3 expresiones también son equivalentes, hacen exactamente lo mismo:
head(penguins, n = 4)         #- forma habitual de llamar/usar la función head()
penguins %>% head(. , n = 4)  #- usando el operador pipe (con el punto actuando como placeholder)
penguins %>% head(n = 4)      #- usando el operador pipe (SIN el punto)

#- ¿Qué hace la siguiente expresión?
4 %>% head(penguins, .)

#- ¿por qué no funciona la siguiente expresión?
4 %>% head(penguins)

#- Intenta descubrir/entender que hace la siguiente expresión:
letters %>% paste0( "-----" ,  .  ,  "!!!" ) %>% toupper

#- TIDYR: Tidy data ------------------------------------------------------------

#- slide nº 12 -----------------------------------------------------------------
#-Tidy data ... algunos ejemplos

#- Ejemplo 1
data_1 <- data.frame(
  year  = c("2014", "2015", "2016"),
  Pedro = c(100, 500, 200),
  Carla = c(400, 600, 250),
  María = c(200, 700, 900))

DT::datatable(data_1)


#- Ejemplo 2
data_2 <- data.frame(names = c("Pedro", "Carla", "María"),
                     W_2014 = c(100, 400, 200),
                     W_2015 = c(500, 600, 700),
                     W_2016 = c(200, 250, 900)   )
knitr::kable(data_2)

data_wide <- data_2

#- Ejemplo 3
data_3 <- data.frame(
  names =rep(c("Pedro", "Carla", "María"), times = 3),
  year = rep(c("2014", "2015", "2016"), each = 3),
  salario = c(100, 400, 200, 500, 600, 700, 200, 250,900) )

gt::gt(data_3)


#- slide nº 14 -----------------------------------------------------------------

#- De wide a LONG format con pivot_longer()
data_wide <- data.frame(names = c("Pedro", "Carla", "María"),
                        w_2014 = c(100, 400, 200),
                        w_2015 = c(500, 600, 700),
                        w_2016 = c(200, 250, 900) )

#- Solución: para pasarlo a formato LONG

data_long <- data_wide %>%
  tidyr::pivot_longer(cols = 2:4, names_to = "periodo")

#- slide nº 15 -----------------------------------------------------------------
#- De long a WIDE format con pivot_wider()

data_wide2 <- data_long %>%
  tidyr::pivot_wider(names_from = periodo,
                     values_from = value)


#- slide nº 17 -----------------------------------------------------------------
#- las funciones separate() y unite()
df <- data.frame( names = c("Pedro_Navaja", "Bob_Dylan", "Cid_Campeador"),
                  year  = c(1978, 1941, 1048) )
gt::gt(df)

#- separo la primera columna
df_a <- df %>%
  separate(col = names,
           into = c("Nombre", "Apellido"),
           sep  = "_")

gt::gt(df_a)

#- vuelvo a unir las columnas
df_b <- df_a %>%
  unite(Nombre_y_Apellido,
        Nombre:Apellido,
        sep = "&")

gt::gt(df_b)

#- DPLYR -----------------------------------------------------------------------
#- slide nº 22 -----------------------------------------------------------------

#- 1.A filter(): permite seleccionar filas (x criterios lógicos)
gapminder <- gapminder::gapminder  #- cargamos los datos


#- Observaciones de España (country == "Spain")
aa <- gapminder %>% filter(country == "Spain")

#- filas con valores de "lifeExp" < 29
aa <- gapminder %>% filter(lifeExp < 29)

#- filas con valores de "lifeExp" entre [29, 32]
aa <- gapminder %>% filter(lifeExp >=  29 , lifeExp <= 32)
aa <- gapminder %>% filter(lifeExp >=  29 &  lifeExp <= 32)
aa <- gapminder %>% filter(between(lifeExp, 29, 32))

#- observaciones de países de África con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent == "Africa")

#- observaciones de países de África o Asia con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )
aa <- gapminder %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


#- slide nº 23 -----------------------------------------------------------------

#- 1.B slice(): tb permite seleccionar filas pero por posición.
#- selecciona las observaciones de la décima a la quinceava
aa <- gapminder %>% slice(c(10:15))

#- selecciona las observaciones de la 11 a 13 Y de la 41 a 43, Y las 3 últimas filas
#- deberían seleccionarse 9 filas, pero ... cometemos un error
aa <- gapminder %>%
  slice( c(11:13, 41:43, n()-3:n()) ) #- AQUI hay un error, tenéis que arreglarlo.


#- Pista: igual os ayuda ver q hace la siguiente expresión
15-3:15


#- slide nº 24 -----------------------------------------------------------------
#- 1.C Variantes de slice()

#- selecciona las 3 filas con mayor valor de lifeExp
aa <- gapminder %>% slice_max(lifeExp, n = 3)

#- selecciona las 4 filas con MENOR valor de pop
aa <- gapminder %>% slice_min(pop, n = 4)

#- observaciones en el primer décil en cuanto a esperanza de vida, 10% con menor esperanza de vida
aa <- gapminder %>% slice_min(lifeExp, prop = 0.1)

#- 1% de observaciones con mayor población. Imagino que estarán China e India
aa <- gapminder %>% slice_max(pop, prop = 0.01)

#- A veces se necesita obtener una muestra aleatoria de los datos: por ejemplo con slice_sample():
#- selecciona (aleatóriamente) 100 filas de los datos
aa <- gapminder %>% slice_sample(n = 100)

#- selecciona (aleatóriamente) un 5% de los datos
aa <- gapminder %>% slice_sample(prop = 0.05)


#- slide nº 25 -----------------------------------------------------------------
#- arrange(): permite reordenar las filas de un df
#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(desc(lifeExp))

#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp.
#- Si hay empates se resuelve con la variable "pop"
aa <- gapminder %>% arrange(lifeExp, pop)



#- slide nº 26 -----------------------------------------------------------------
#- rename(): permite cambiar los nombres de las variables
aa <- gapminder

aa %>% rename_with(toupper)

rename_with(aa, toupper, starts_with("Life") | contains("countr"))

rename_with(aa, ~ str_replace(.x, "e", "Ö"))  #- (!!!!)



#- slide nº 27 -----------------------------------------------------------------
#- select() se utiliza para seleccionar variables

#- por nombre--
aa <- gapminder %>% select(year, lifeExp)

#- por posición--
aa <- gapminder %>% select(1:3, 5)

#- eliminar variables --
aa <- gapminder %>% select(-year)

aa <- gapminder %>% select(-c(year, lifeExp))

#- eliminar variables por posicion
aa <- gapminder %>% select(-c(1:3, 5))


#- slide nº 28 -----------------------------------------------------------------
#- select() junto con where()
aa <- gapminder %>% select(is.numeric)        #- funciona, pero ...

aa <- gapminder %>% select(where(is.numeric)) #- es "preferible" esta segunda expresión

aa <- gapminder %>% select(!where(is.numeric)) #- seleccionamos las v. no-numericas



#- slide nº 29 -----------------------------------------------------------------
#- reordenar las v. del df

#- dejamos en aa solamente a las columnas "year" y "pop"; ADEMÁS, ahora, "pop" irá antes que "year"
aa <- gapminder %>% select(pop, year)

#- dejamos en aa solamente a las columnas "year" y "pop" y les cambiamos el nombre
aa <- gapminder %>% select(poblacion = pop, año = year)

#- everything() es util
#- "gdpPercap" que es la última columna pasa a ser la primera
aa <- gapminder %>% select(gdpPercap, everything())

#- relocate() para posicionar una v.
aa <- gapminder %>% dplyr::relocate(country, .after = lifeExp)
aa <- gapminder %>% dplyr::relocate(country, .before = lifeExp)



#- slide nº 30 -----------------------------------------------------------------
#- mutate() para crear nuevas variables
aa <- gapminder %>% mutate(GDP = pop*gdpPercap)

#- las podemos situar donde queramos [🌶]
aa <- gapminder %>% mutate(GDP = pop*gdpPercap, .after = country)
aa <- gapminder %>% mutate(GDP = pop*gdpPercap, .before = country)



#- slide nº 31 -----------------------------------------------------------------
#-  summarize() para "resumir" variables
aa <- gapminder %>% summarise(media = mean(lifeExp))
aa <- gapminder %>% summarise(desviacion_tipica = sd(lifeExp))
aa <- gapminder %>% summarise(max(pop))
aa <- gapminder %>% summarise(NN = n())
aa <- gapminder %>% count()      #- más adelante veremos la utilidad de count()

#- resumimos 2 variables
#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- gapminder %>% summarise(mean(lifeExp), mean(gdpPercap))

#- 2 resúmenes de 1 variable
#- retornará 2 valores: la media y sd de la v. "lifeExp"
aa <- gapminder %>% summarise(mean(lifeExp), sd(lifeExp))




#- slide nº 32 -----------------------------------------------------------------
#- 6.B summarize() con across()

#- media de cada una de las 6 variables. Devuelve 2 warnings porque las 2 primeras son textuales. No se puede calcular la media de continent y country
gapminder %>% summarise(across(everything(), mean) )

#- calculamos la media de tercera a la sexta variable
gapminder %>% summarise(across(3:6, mean) )

#- Dentro de across() se puede utilizar where() para aplicar criterios lógicos para seleccionar variables: [🌶] [ 🌟 ]
gapminder %>% summarise(across(where(is.numeric), mean))

#- con los nombres de los argumentos (más largo pero conviene verlo de vez en cuando)
gapminder %>% summarise(across(.cols = where(is.numeric), .fns = mean))


#- slide nº 33 -----------------------------------------------------------------
#- summarize() con across() y varias funciones(list)

#- calculamos la media y desviación típica de las columnas 3 a 6.
gapminder %>% summarise(across(3:6, list(media = mean, desv = sd)))

#- lo mismo, pero explicitando los nombres de los argumentos [🌶]
gapminder %>% summarise(across(.cols = 3:6, .fns = list(media = mean, desv = sd) ))

#- lo mismo otra vez, pero eligiendo el nombre de las variables que se van a crear con .names [🌶] [🌶]
gapminder %>% summarise(across(3:6, list(media = mean, desv = sd), .names = "{fn}_{col}"))



#- slide nº 34 -----------------------------------------------------------------
#- group_by(). Con está función ya se puede ver la potencia de dplyr

aa <- gapminder %>% group_by(continent) %>% summarise(NN = n())

aa


#- slide nº 35 -----------------------------------------------------------------
#- Usando group_by()

#- Pregunta: ¿cuantos países hay en la base de datos?
aa <- gapminder %>%
      group_by(country) %>%
      summarize(NN = n())

aa %>% nrow()

#- slide nº 36 -----------------------------------------------------------------
#- Pregunta: ¿cuantos países hay en la base de datos?

#- Un poco mejor
aa <- gapminder %>% group_by(country) %>%
  summarize(NN = n()) %>%
  mutate(NN_paises = n())

#- Mejor?!
aa <- gapminder %>%
  summarise(NN_paises = n_distinct(country))

#- slide nº 37 y 38 ------------------------------------------------------------
#- Usando group_by()

#- Pregunta: ¿cuantos países hay en cada continente?
#- cogemos df y lo agrupamos por "continent",
#- después calculamos 2 cosas: el número de observaciones o rows
#- y el número de países (distintos) en cada continente (NN_countries_cont)
aa <- gapminder %>% group_by(continent) %>%
  summarize(NN_obs = n(),
            NN_countries_cont = n_distinct(country))
aa

#- ahora el nº total de paises
bb <- aa %>%
  mutate(NN_countries = sum(NN_countries_cont))

bb


#- slide nº 39 -----------------------------------------------------------------
#- Usando group_by()
#- Pregunta: ¿cuantos países hay en cada continente?  à la R-base

aa <- gapminder %>% group_by(continent) %>%
  summarize(NN = n(),
            NN_countries = length(unique(country)) )

aa


#- slide nº 41 -----------------------------------------------------------------
#- Ejemplos para practicar con  `dplyr`



#- slide nº 42 -----------------------------------------------------------------
#- Más ejemplos (para recordar across())



#- slide nº 44 -----------------------------------------------------------------
#- ¿en que continente ha aumentado más la esperanza de vida en el periodo 1952-2007?



#- slide nº 45 -----------------------------------------------------------------
#- Otra pregunta: ¿qué hace el código de abajo?


#- slide nº 47 -----------------------------------------------------------------
#- Más preguntas de verdad


#- slide nº 48 -----------------------------------------------------------------
#- A ver si entendéis estos ejemplos



#- JOINS -----------------------------------------------------------------------
#- slide nº 50 -----------------------------------------------------------------
#- Dos casos ideales (sencillos de unir): bind_cols() y bind_rows()

df_1 <- iris[ , 1:2]  ; df_2 <- iris[ , 3:5]
df_1 <- iris %>% select(1:2)  ; df_2 <- iris %>% select(3:5)
df_3 <- bind_cols(df_1, df_2)
identical(iris, df_3)


df_1 <- iris[1:75, ]  ; df_2 <- iris[76:150, ]
df_1 <- iris %>% slice(1:75)  ; df_2 <- iris %>% slice(76:150)
df_3 <- bind_rows(df_1, df_2)
identical(iris, df_3)


#- slide nº 52 y 53 ------------------------------------------------------------
x <- tibble(id = 1:3, x = paste0("x", 1:3))
y <- tibble(id = (1:4)[-3], y = paste0("y", (1:4)[-3]))

df_inner <- inner_join(x, y)

df_full_join <- full_join(x, y)

df_left_join <- left_join(x, y)

