#- pedro.j.perez@uv.es [revisado: 2024-09-04]
#- Ejemplo nº 01 del curso: vamos a hacer memes con el pkg "meme"
#- repo del paquete:  https://github.com/GuangchuangYu/meme/

#- lógicamente, para poder usar el paquete, este tiene q estar instalado y cargado
library(tidyverse)
library(meme)    #- install.packages("meme")

#- primer meme: la foto está dentro del package "meme" -------------------------
ruta_a_imagen <- system.file("success.jpg", package = "meme") 

#- fijate q el objeto con nombre "ruta_a_imagen" no es una imagen, es la ruta a la imagen/archivo "succes.jpg"
ruta_a_imagen
#- Igual las 3 lineas siguientes te ayuda a entenderlo
library(imager)
la_imagen <- load.image(ruta_a_imagen)
plot(la_imagen)



#-  usamos la función "meme" para hacer el meme
#- la función tiene varios argumentos (separados por comas)
meme(ruta_a_imagen, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0, color = "purple")


#- segundo meme: usamos una foto que está en internet --------------------------
ruta_a_imagen <- "https://i1.wp.com/production-wordpress-assets.s3.amazonaws.com/blog/wp-content/uploads/2013/03/wisdom_of_the_ancients-1.png?resize=485%2C270&ssl=1"

meme(ruta_a_imagen, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")


#- tercer meme: utilizamos una foto de nuestro ordenador. La foto está en "./imagenes/NV.jpg" ----
#- fijate que como estamos trabajando con un Rproject usamos una ruta relativa
ruta_a_imagen <- "./imagenes/NV.jpg"

meme(ruta_a_imagen, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")





#- Por cierto, hay paquetes más completos para hacer memes, pero este seguro que nos funcionaba. Si te interesa el tema mira este post: http://jenrichmond.rbind.io/post/making-memes-in-r/
#- entre otros paquetes, habla del pkg memer: https://github.com/sctyner/memer

#- pkg memer -------------------------------------------------------------------
#- devtools::install_github("sctyner/memer")
library(memer)
meme_list() #- lista de memes

# Creaando memes con el pkg "memer"
meme_get("DistractedBf") %>% meme_text_distbf("tidyverse", "new R users", "base R")

meme_explain("DistractedBf") #- podemos ver la historia/origen de un meme

memer::meme_get("AgnesWink") %>% memer::meme_text_bottom("No hace falta que curreís en casa, \n con las clases sobra!!!")

meme_get("AnakinPadmeRight") 



#- Mas memes -------------------------------------------------------------------
#- https://blog.ephorie.de/create-bart-simpson-blackboard-memes-with-rlibrary(meme)

#- el meme de Bart es esencial para dar consejos en clase y en unas slides
url <- "http://free-extras.com/pics/b/bart_simpson_chalkboard-5157.gif"
url <- here::here("imagenes", "bart_simpson_chalkboard-5157.gif")

meme::meme(url, "Al instalar paquetes .... \n  ... siempre sesión LIMPIA!!")


meme::meme(url, font = "Comic Sans MS", upper = "Please, \n deja los Rprojects \n en el escritorio!!!")


meme::meme(url, 
           font = "Impact", 
           color = "blue",
           bgcolor = "orange", r = 0.2,
           upper = "Please, configura tu RStudio", 
           lower = "Save workspace? Never \n  save code? as UTF-8",
           vjust = 0.2)

