#- pedro.j.perez@uv.es [revisado: 2024-09-04]
#- ejemplo con datos INE (EPA)

#- script para procesar datos de la EPA
#- https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=ultiDatos&idp=1254735976595

library(tidyverse)
library(sf)

#- hay datos en tablas y datos completos (los microdatos)


#- por ejemplo esta TABLA: https://www.ine.es/jaxiT3/Tabla.htm?t=4247&L=0
#- contiene la Tasas de paro por distintos grupos de edad, sexo y comunidad autónoma
#- Esta tabla se puede descargar en varios formatos. Por ejemplo lo descargaré en .csv, .xlsx y pcaxis
#- Estos son los enlaces:
#- https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1

#- en csv ----------------------------------------------------------------------
#- salen decentes y en formato ancho (la coma para decimales mal)
fs::dir_create("pruebas") #- primero creamos la carpeta "pruebas"
my_url <- "https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.csv")
df_csv <- rio::import("./pruebas/epa_tab_1.csv")

#- en xlsx ---------------------------------------------------------------------
#- bueno, no salen decentes, habría que arreglarlos
#- quizas para vosotros sea mejor arreglarlos en Excel (!!!!!)
my_url <- "https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.xlsx")
df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx")

#- se pueden arreglar, pero ....
df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx", skip = 7)
#- habría q pasarlo a largo (y lo complica el hecho de que Total, H y M, ...)


#- en pcaxis (es casi simepre mucho más fácil) ---------------------------------
#- salen decentes y en formato ancho
# library(pxR) #- install.package("pxR")

my_url <- "https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.px")
df_px <- pxR::read.px("./pruebas/epa_tab_1.px") %>% as.data.frame


#- microdatos ------------------------------------------------------------------
#- es otra historia (algo diré en clase)

dicc <- rio::import("https://www.ine.es/ftp/microdatos/epa/dr_EPA_2021.xlsx")

#- Los microdatos se descargan en un fichero .zip con los datos en muchos formatos
#- abrimos ficheros en varios formatos -----------------------------------------
#- no funcionará xq no hemos bajado esos ficheros
# epa_sas <- haven::read_sas("tmp/SAS/epa_2020t3.sas7bdat", NULL)
# epa_spss <- haven::read_sav("tmp/SPSS/EPA_2020T3.sav")
# epa_stata <- haven::read_dta("tmp/STATA/EPA_2020T3.dta")
# epa_csv <- readr::read_delim("tmp/CSV/EPA_2020T3.csv", "\t", escape_double = FALSE, locale = locale(date_names = "es"), trim_ws = TRUE)



#- vamos a arreglar/usar una tabla ---------------------------------------------
rm(list= ls())

df_csv <- rio::import("./pruebas/epa_tab_1.csv")
names(df_csv)

df <- janitor::clean_names(df_csv) #- arreglo nombres
names(df)

#- vemos q hay en la tabla
df_dicc <- pjpv.curso.R.2022::pjp_dicc(df)


#- renombro 1 v. y me quedo con los Totales (tanto en genero como en edad)
df <- df %>%
  dplyr::rename(CCAA = comunidades_y_ciudades_autonomas) %>%
  filter(sexo == "Ambos sexos") %>%
  filter(edad == "Total")
str(df)

#- la v. fecha está como texto ("2022T3") la pasamos a fecha
df <- df %>%
  mutate(fecha = lubridate::yq(periodo))
str(df)
#- para ver como se almacenan realmente las fechas
zz <- df %>% mutate(fecha_x = unclass(fecha))


#- me quedo con los totales para ESP  ------------------------------------------
#- y hago un gráfico chapucero
df_esp <- df %>%
  filter(CCAA == "Total Nacional") %>%
  select(-c(edad, sexo))

ggplot(df_esp, aes(x = fecha, y = total, group = 1)) +
  geom_line() + geom_point()

