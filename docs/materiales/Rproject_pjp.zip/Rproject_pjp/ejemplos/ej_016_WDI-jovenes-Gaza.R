#- pedro.j.perez@uv.es [2024-04-09]

#- viene de aquí, pero ...
#- https://blog.ephorie.de/the-forgotten-factor-in-the-middle-east-conflict-youth-bulge-theory?utm_source=rss&utm_medium=rss&utm_campaign=the-forgotten-factor-in-the-middle-east-conflict-youth-bulge-theory

library(tidyverse)
library(WDI)
#- WDI pkg (datasets hosted by the World Bank):  https://vincentarelbundock.github.io/WDI/
WDI_catalog_series <- WDI::WDI_data[[1]]
WDI_catalog_paises <- WDI::WDI_data[[2]]

my_search <- WDI::WDIsearch(string = "Population ages 0-14", field = "name") #- población entre 0 y 14 años

my_serie <- "SP.POP.0014.TO.ZS" #- Population between the ages 0 to 14 as a percentage of the total population.

age0_14 <- WDI(indicator = my_serie)
age0_14_2022<- age0_14 %>% filter(year == 2022)
age_spain <- age0_14 %>% filter(country == "Spain")
age_gaza <- age0_14 %>% filter(country == "West Bank and Gaza")
age_Niger <- age0_14 %>% filter(country == "Niger")





#- un ejemplo ----------
# my_indicator <- c("Population between the ages 0 to 14 (% of total pob)" = "SP.POP.0014.TO.ZS")

my_serie <- "SP.POP.0014.TO.ZS" #- Population between the ages 0 to 14 as a percentage of the total population.


df <- WDI::WDI(indicator = my_serie)

#- podemos seleccionar una area
vv_regiones <- WDI_catalog_paises %>% distinct(region)
my_region <- "Europe & Central Asia"
 
#- y así coger los países de ese área
my_paises_area <- WDI_catalog_paises %>% filter(region == my_region) %>% pull(country)

#- un ggplot
df %>%
  filter(country %in% my_paises_area) %>%
  ggplot(aes(x = year, y = SP.POP.0014.TO.ZS)) + geom_line() +
  facet_wrap(vars(country), scales = "free_y")

#- ahora usando NSE (y más cosas: geom_hline() y labs())
df %>%
  filter(country %in% my_paises_area) %>%
  ggplot(aes(x = year, y = !!sym(my_serie))) + #- !! NSE: https://adv-r.hadley.nz/evaluation.html#tidy-evaluation
  geom_line() +
  facet_wrap(vars(country), scales = "free_y") +
  geom_hline(yintercept = 20, col = "green") +
  geom_hline(yintercept = 15, col = "orange") +
  labs(title = "Population between the ages 0 to 14 (% of total population)", x = "Year", y = "Percentage") 


#- ahora hacemos un bucle para ver todas las áreas (vv_regiones)

my_plots <- list()  #- lista para guardar los plots

for (i in 1:nrow(vv_regiones)) {
  my_region <- vv_regiones$region[i]
  my_paises_area <- WDI_catalog_paises %>% filter(region == my_region) %>% pull(country)
  my_plot <- df %>%
    filter(country %in% my_paises_area) %>%
    ggplot(aes(x = year, y = !!sym(my_serie))) + #- !! NSE: https://adv-r.hadley.nz/evaluation.html#tidy-evaluation
    geom_line() +
    facet_wrap(vars(country), scales = "free_y") +
    geom_hline(yintercept = 20, col = "green") +
    geom_hline(yintercept = 15, col = "orange") +
    labs(title = "Population between the ages 0 to 14 (% of total population)", x = "Year", y = "Percentage") 
  my_plots[[i]] <- my_plot
}

my_plots[[1]]

my_areas <- WDI_catalog_paises %>% distinct(region) %>% pull(region)


#- ahora vamos a hacer una tabla
#- https://rpubs.com/svanhorne/DE_enrollment
library(gt)
zz <- df %>% 
  rename(Jovenes_percent = SP.POP.0014.TO.ZS) |> 
  mutate(Jovenes_percent = round(Jovenes_percent, 2)) |>
  filter(country %in% my_paises_area) %>% 
  select(year, country, Jovenes_percent) |> 
  filter(year %in% c(1960, 1970, 1980, 1990, 2000, 2010, 2020, 2022)) |>
  arrange(year) %>% 
  pivot_wider(names_from = year, names_prefix = "yy_", values_from = Jovenes_percent) 


gt(zz) |> 
  tab_header("% de población jovén (0-14 años)") |> 
  fmt_number(columns = starts_with("SchoolYear_"), decimals = 2) |> 
  cols_label(country = "País",
             yy_1960 = "1960",
             yy_2022 = "2022") |> 
  cols_nanoplot(
    columns = starts_with("yy_"),
    new_col_name = "trend",
    new_col_label = "1960-2022") %>% 
  cols_hide(columns = matches("yy_1970|yy_1980|yy_1990|yy_2000|yy_2010|yy_2020")) 


#- otra tabla
DT::datatable(zz, rownames = FALSE, options = list(pageLength = 50, scrollX = TRUE))




#- el post sobre Youth Bulge Theory ------
#- https://blog.ephorie.de/the-forgotten-factor-in-the-middle-east-conflict-youth-bulge-theory?utm_source=rss&utm_medium=rss&utm_campaign=the-forgotten-factor-in-the-middle-east-conflict-youth-bulge-theory


#age0_14 <- WDI(indicator = "SP.POP.0014.TO.ZS") # proportion of 0-14 year old 
#pol_stab <- WDI(indicator = "PV.EST") # political stability indicator

age0_14 <- WDI(indicator = "SP.POP.0014.TO.ZS", start = 2021, end = 2021) # proportion of 0-14 year olds 
pol_stab <- WDI(indicator = "PV.EST", start = 2021, end = 2021) # political stability indicator

datos <- full_join(age0_14, pol_stab)
datos_dicc <- pjpv.curso.R.2022::pjp_dicc(datos)

#- es un base-R!! :)

data <- merge(age0_14, pol_stab)[c(1, 5, 6)] |> na.omit()
colnames(data) <- c("country", "age0_14", "pol_stab")

plot(data$age0_14, data$pol_stab, col = "darkgrey", xlab = "Proportion of young people (in %)", ylab = "Political stability", main = "Youth Bulge Theory")
abline(v = 23.2, col = "red") # cut-off value
abline(h = 0, col = "red")
lm_out <- lm(pol_stab ~ age0_14, data = data) 
abline(lm_out, col = "black", lwd = 3)

country <- "West Bank and Gaza"
points(data$age0_14[data$country == country], data$pol_stab[data$country == country], col = "darkgreen", lwd = 8)
text(data$age0_14[data$country == country], data$pol_stab[data$country == country], labels = country, pos = 4)

country <- "Israel"
points(data$age0_14[data$country == country], data$pol_stab[data$country == country], col = "blue", lwd = 8)
text(data$age0_14[data$country == country], data$pol_stab[data$country == country], labels = country, pos = 4)

country <- "Germany"
points(data$age0_14[data$country == country], data$pol_stab[data$country == country], col = "orange", lwd = 8)
text(data$age0_14[data$country == country], data$pol_stab[data$country == country], labels = country, pos = 4)
