#- Seguir trabajando el manejo de datos y practicar la unión de tablas

#- cargamos los datos ----------------------------------------------------------
library(tidyverse)
df_pob <- rio::import(here::here("datos", "df_pob_mun.rds")) %>% 
  select(year, ine_muni, ine_muni.n, poblacion, pob_values, ine_prov, ine_prov.n, capital_prov)

df_bebes <- rio::import(here::here("datos", "df_bebes_16y19.rds")) %>% 
      select(year_parto, muni_inscrip, muni_inscrip.n, prov_inscrip, prov_inscrip.n, 
             sexo_bebe, peso_bebe, edad_madre, edad_padre) 


#- Pregunta 1: -----------------------------------------------------------------
#- ¿Que 10 municipios tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
#- Pistas: con df_bebes puedes calcular el nº de bebes en cada municipio y en df_pob está el número de mujeres en cada municipio, solo tienes que hacerlo y juntar las tablas y ....




#- Pregunta 2: -----------------------------------------------------------------
#- ¿Que 10 provincias tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000




#- SOLUCIONES ------------------------------------------------------------------

#- ss_01 -----------------------------------------------------------------------


#- nº de mujeres en cada municipio en 2019
df_pob_M <- df_pob %>% 
  filter(year == 2019) %>% 
  filter(poblacion == "pob_mujeres") %>% 
  select(pob_values, ine_muni, ine_muni.n, ine_prov.n, capital_prov) 

#- bebes totales nacidos en 2019 en cada municipio
df_bebe_T <- df_bebes %>% 
  filter(year_parto == 2019) %>% 
  group_by(muni_inscrip, muni_inscrip.n, prov_inscrip.n) %>% 
  summarise(nn_bebes = n())  %>%     #- tb se puede con count()
  ungroup()

#- salen NAs xq el INE no da los datos de los municipios de menos de 10.000 habitantes
#- quito los NAs
df_bebe_T <- df_bebe_T %>% 
  filter(!is.na(muni_inscrip))

#- hemos de juntar las 2 tablas
df <- left_join(df_bebe_T, df_pob_M, by = c("muni_inscrip" = "ine_muni")) %>% 
  select(- muni_inscrip.n, - prov_inscrip.n)

#- ahora ya calculamos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
df <- df %>% 
  mutate(tasa_natalidad = (nn_bebes / pob_values)*1000, .after = pob_values) %>% 
  arrange(desc(tasa_natalidad))



#- vamos a visualizarlo 
library(sf)
geometrias <- pjpv.datos.01::LAU2_muni_2020_canarias

df_map <- left_join(geometrias, df)

p <- ggplot(df_map, aes(fill = tasa_natalidad)) +
  geom_sf(color = NA) 

p    #- ya lo mejoraremos!!


p + scale_fill_viridis_c(option = "magma")  #- ya lo mejoraremos




#- ss_02 -----------------------------------------------------------------------



#- nº de mujeres en cada PROVINCIA en 2019
df_pob_M_prov <- df_pob %>% 
  filter(year == 2019) %>% 
  filter(poblacion == "pob_mujeres") %>% 
  select(pob_values, ine_prov,  ine_prov.n) %>% 
  group_by(ine_prov,  ine_prov.n) %>% 
  summarise(pob_values = sum(pob_values, na.rm = TRUE)) %>%   #- no hace falta na.rm = TRUE, pero ...
  ungroup()


#- bebes totales nacidos en 2019 en cada PROVINCIA:
#- Ya no salen NAs, xq calculamos a nivel provincial, no municipal (el INE solo oculta el municipio de nacimiento, si es municipio pequeño, pero no oculta la provincia de nacimiento)
df_bebe_T_prov <- df_bebes %>% 
  filter(year_parto == 2019) %>% 
  group_by(prov_inscrip, prov_inscrip.n) %>% 
  summarise(nn_bebes = n())  %>%     #- tb se puede con count()
  ungroup()


#- hemos de juntar las 2 tablas
df_prov <- left_join(df_bebe_T_prov, df_pob_M_prov, by = c("prov_inscrip" = "ine_prov")) 

#- ahora ya calculamos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
df_prov <- df_prov %>% 
  mutate(tasa_natalidad = (nn_bebes / pob_values)*1000, .after = pob_values) %>% 
  arrange(desc(tasa_natalidad))



#- vamos a visualizarlo --
library(sf)
geometrias <- pjpv.datos.01::LAU2_prov_2020_canarias

df_map_prov <- left_join(geometrias, df_prov)

p <- ggplot(df_map_prov, aes(fill = tasa_natalidad)) +
  geom_sf(color = "black") 
p

p + scale_fill_viridis_c(option = "plasma") + #- ya lo mejoraremos
  theme_void() +
  labs(title = "Venga a currar!!! \U1F600", size = 30) +
  annotate(geom = "text", 
           label = "A currar!!",
           x = 2.3,
           y = 37,
           size = 6)



